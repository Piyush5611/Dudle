<?php require("top.php")?>

    <div class="hero-section hero-background">
        <h1 class="page-title">Title</h1>
    </div>

    
    <div class="page-contain login-page">

        <!-- Main content -->
        <div id="main-content" class="main-content">
            <div class="container">
                <div class="row">

                    <!--Form Sign In-->
                    <div class="col-7 col-md-6 col-sm-6 col-xs-12">
                        <div class="signin-container">
                            <form action="#" name="frm-login" method="post">
                                <p class="form-row">
                                    <label for="fid-name">Email Address:<span class="requite">*</span></label>
                                    <input type="text" id="fid-name" name="name" value="" class="txt-input">
                                </p>
                                <p class="form-row">
                                    <label for="fid-pass">Password:<span class="requite">*</span></label>
                                    <input type="email" id="fid-pass" name="email" value="" class="txt-input">
                                </p>
                                <p class="form-row wrap-btn">
                                <a href="#" class="btn btn-bold">Login</a>
                                <a href="#" class="link-to-help">Forgot your password</a>
                                </p>
                            </form>
                        </div>
                    </div>

                    <!--Go to Register form-->
                    <div class="col-7 col-md-6 col-sm-6 col-xs-12">
                        <div class="register-in-container">
                            <div class="intro">
                                <h4 class="box-title">New Customer?</h4>
                                <p class="sub-title">Sub-Title</p>
                                <ul class="lis">
                                    <li>First Line</li>
                                    <li>Second Line</li>
                                    <li>Third Line</li>
                                    <li>Fourth Line</li>
                                    <li>Fifth Line</li>
                                </ul>
                                <a href="register.php" class="btn btn-bold">Create an account</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   </div>
<?php require("footer.php")?>