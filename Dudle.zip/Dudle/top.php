<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dudle</title>
    <link href="https://fonts.googleapis.com/css?family=Cairo:400,600,700&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:600&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400i,700i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Ubuntu&amp;display=swap" rel="stylesheet">
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png" />
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/slick.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/main-color02.css">
</head>
<body class="dudle-body">

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-02">
        <div class="header-top bg-main hidden-xs">
            <div class="container">
                <div class="top-bar left">
                    <ul class="horizontal-menu">
                        <li><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i>xyz@gmail.com</a></li>
                        <li><a href="#">Lorem ipsum dolor sit.</a></li>
                    </ul>
                </div>
                <div class="top-bar right">
                    <ul class="social-list">
                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="#" title="instagram" class="socail-btn"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                    </ul>
                    <ul class="horizontal-menu">
                        <li class="item-link"><a href="javascript:void(0)" class="dsktp-open-searchbox"><i class="dudle-icon icon-search"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="header-middle dudle-sticky-object ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-6 hidden-sm hidden-xs">
                        <div class="primary-menu">
                            <ul class="menu dudle-menu clone-main-menu clone-primary-menu">
                                <li class="menu-item"><a href="index.php">Home</a></li>
                                <li class="menu-item menu-item-has-children has-child">
                                    <a href="#" class="menu-name" data-title="Product">Title</a>
                                    <ul class="sub-menu">
                                        <li class="menu-item"><a href="#">Product 1</a></li>
                                        <li class="menu-item"><a href="#">Product 2</a></li>
                                        <li class="menu-item menu-item-has-children has-child"><a href="#" class="menu-name" data-title="Eggs & other considerations">Product 3</a>
                                            <ul class="sub-menu">
                                                <li class="menu-item"><a href="#">Product 3.1</a></li>
                                                <li class="menu-item"><a href="#">Product 3.2</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item"><a href="#">Product 4</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item menu-item-has-children has-child">
                                    <a href="#" class="menu-name" data-title="Product">Product Title</a>
                                    <ul class="sub-menu">
                                        <li class="menu-item"><a href="#">Product 1</a></li>
                                        <li class="menu-item"><a href="#">Product 2</a></li>
                                        <li class="menu-item menu-item-has-children has-child"><a href="#" class="menu-name" data-title="Eggs & other considerations">Product 3</a>
                                            <ul class="sub-menu">
                                                <li class="menu-item"><a href="#">Product</a></li>
                                                <li class="menu-item"><a href="#">Product</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item"><a href="#">Product</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item"><a href="contact.php">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6">
                        <a href="index.php" class="dudle-logo "><img src="assets/images/logo.png" alt="dudle logo" class="dud-log" width="135" height="20"></a>
                    </div>
                    <div class="col-lg-5 col-md-4 col-sm-6 col-xs-6">
                        <div class="dudle-cart-info">
                            <div class="mobile-search">
                                <a href="javascript:void(0)" class="open-searchbox"><i class="dudle-icon icon-search"></i></a>
                                <div class="mobile-search-content">
                                    <form action="#" class="form-search" name="mobile-seacrh" method="get">
                                        <a href="#" class="btn-close"><span class="dudle-icon icon-close-menu"></span></a>
                                        <input type="text" name="s" class="input-text" value="" placeholder="Search here...">
                                        <button type="submit" class="btn-submit">go</button>
                                    </form>
                                </div>
                            </div>
                            <div class="login-item">
                                <a href="login.php" class="login-link"><i class="dudle-icon icon-login"></i>Login/Register</a>
                            </div>
                            <div class="wishlist-block hidden-sm hidden-xs">
                                <a href="#" class="link-to">
                                    <span class="icon-qty-combine">
                                        <i class="icon-heart-bold dudle-icon"></i>
                                        <span class="qty">0</span>
                                    </span>
                                </a>
                            </div>
                            <div class="minicart-block">
                                <div class="minicart-contain">
                                    <a href="cart.php" class="link-to">
                                            <span class="icon-qty-combine">
                                                <i class="icon-cart-mini dudle-icon"></i>
                                                <span class="qty">0</span>
                                            </span>
                                        <span class="title">Cart</span>
                                    </a>
                                </div>
                            </div>
                            <div class="mobile-menu-toggle">
                                <a class="btn-toggle" data-object="open-mobile-menu" href="javascript:void(0)">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>