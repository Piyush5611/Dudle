<?php require("top.php")?>

    <div class="hero-section hero-background">
        <h1 class="page-title">Title</h1>
    </div>

    
    <div class="page-contain login-page">

        <!-- Main content -->
        <div id="main-content" class="main-content">
            <div class="container">
                <div class="row">

                    <!--Form Sign In-->
                    <div class="col-7 col-md-6 col-sm-6 col-xs-12">
                        <div class="signin-container">
                            <form action="#" name="frm-login" method="post">
                                <p class="form-row">
                                    <label for="fid-name">Enter Your Email Address:<span class="requite">*</span></label>
                                    <input type="email" id="fid-name" name="email" value="" class="txt-input">
                                </p>
                                <p class="form-row">
                                    <label for="fid-name">Enter Your Name:<span class="requite">*</span></label>
                                    <input type="text" id="fid-name" name="name" value="" class="txt-input">
                                </p>
                                
                                <p class="form-row">
                                    <label for="fid-pass">Enter Your Phone Number<span class="requite">*</span></label>
                                    <input type="text" id="fid-pass" name="num" value="" class="txt-input">
                                </p>
                                <p class="form-row wrap-btn">
                                <a href="#" class="btn btn-bold">Login</a>
                                <a href="#" class="link-to-help">Forgot your password</a>
                                </p>
                            </form>
                        </div>
                    </div>

                    <!--Go to Register form-->
                    <div class="col-7 col-md-6 col-sm-6 col-xs-12">
                        <div class="register-in-container">
                            <div class="intro">
                                <h4 class="box-title">Already Seller?</h4>
                                <a href="seller_login.php" class="btn btn-bold">Login</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   </div>
<?php require("footer.php")?>