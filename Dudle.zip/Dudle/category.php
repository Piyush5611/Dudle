
<?php require("top.php")?>
<!--Hero Section-->
    <div class="hero-section hero-background">
        <h1 class="page-title">Title</h1>
    </div>

    <!--Navigation section-->
    <div class="container">
        <nav class="dudle-nav">
            <ul>
                <li class="nav-item"><a href="index-2.html" class="permal-link">Home</a></li>
                <li class="nav-item"><a href="#" class="permal-link">Title</a></li>
                <li class="nav-item"><span class="current-page">Title</span></li>
            </ul>
        </nav>
    </div>

    <div class="page-contain category-page no-sidebar">
        <div class="container">
            <div class="row">

                <!-- Main content -->
                <div id="main-content" class="main-content col-lg-12 col-md-12 col-sm-12 col-xs-12">

                    <div class="block-item recently-products-cat md-margin-bottom-39">
                        <ul class="products-list dudle-carousel nav-center-02 nav-none-on-mobile" data-slick='{"rows":1,"arrows":true,"dots":false,"infinite":false,"speed":400,"slidesMargin":0,"slidesToShow":5, "responsive":[{"breakpoint":1200, "settings":{ "slidesToShow": 3}},{"breakpoint":992, "settings":{ "slidesToShow": 3, "slidesMargin":30}},{"breakpoint":768, "settings":{ "slidesToShow": 2, "slidesMargin":10}}]}' >
                            <li class="product-item">
                                <div class="contain-product layout-02">
                                    <div class="product-thumb cat-bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                        <div class="price">
                                            <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-02">
                                    <div class="product-thumb cat-bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                        <div class="price">
                                            <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-02">
                                    <div class="product-thumb cat-bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                        <div class="price">
                                            <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-02">
                                    <div class="product-thumb cat-bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                        <div class="price">
                                            <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-02">
                                    <div class="product-thumb cat-bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                        <div class="price">
                                            <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-02">
                                    <div class="product-thumb cat-bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                        <div class="price">
                                            <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-02">
                                    <div class="product-thumb cat-bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                        <div class="price">
                                            <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>

                    <div class="product-category product-category_bottom_margin grid-style">

                        <div class="top-functions-area" ></div>
                        <div class="row">
                            <ul class="products-list">

                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="product-item col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb cat-bg">
                                            <a href="single_product.php" class="link-to-product">
                                                <img src="" alt="dd" width="270" height="270" class="product-thumnail">
                                            </a>
                                        </div>
                                        <div class="info">
                                            <h4 class="product-title"><a href="#" class="pr-name">Product Title</a></h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                                                <del><span class="price-amount"><span class="currencySymbol">..</span>Price</span></del>
                                            </div>
                                            <div class="shipping-info">
                                                <p class="shipping-day">Same Day Shipping</p>
                                            </div>
                                            <div class="slide-down-box">
                                                <p class="message">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cupiditate, similique.</p>
                                                <div class="buttons">
                                                    <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                    <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                              
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php require("footer.php")?>