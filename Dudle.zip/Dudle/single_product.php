<?php require("top.php")?>
    <!--Hero Section-->
    <div class="hero-section hero-background">
        <h1 class="page-title">Title</h1>
    </div>

    <!--Navigation section-->
    <div class="container">
        <nav class="dudle-nav">
            <ul>
                <li class="nav-item"><a href="index-2.html" class="permal-link">Home</a></li>
                <li class="nav-item"><a href="#" class="permal-link">Title</a></li>
                <li class="nav-item"><span class="current-page">Title</span></li>
            </ul>
        </nav>
    </div>

    <div class="page-contain single-product">
        <div class="container">

            <!-- Main content -->
            <div id="main-content" class="main-content">
                
                <!-- summary info -->
                <div class="sumary-product single-layout">
                    <div class="media bg">
                        <ul class="dudle-carousel slider-for">
                            <li><img src="" alt="" width="500" height="500"></li>
                        </ul>
                    </div>
                    <div class="product-attribute">
                        <h3 class="title">Product Title</h3>
                        <p class="excerpt">Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus, cupiditate maiores? Exercitationem molestiae, sequi quae culpa iste blanditiis fugiat, illo alias consectetur nobis quia laudantium in vitae quisquam ipsam quas.</p>
                        <div class="price">
                            <ins><span class="price-amount"><span class="currencySymbol">..</span>Price</span></ins>
                        </div>
                        <div class="shipping-info">
                            <p class="shipping-day">Same Day Shipping</p>
                        </div>
                    </div>
                    <div class="action-form">
                        <div class="quantity-box">
                            <span class="title">Quantity:</span>
                            <div class="qty-input">
                                <input type="text" name="qty12554" value="1" data-max_value="20" data-min_value="1" data-step="1">
                                <a href="#" class="qty-btn btn-up"><i class="fa fa-caret-up" aria-hidden="true"></i></a>
                                <a href="#" class="qty-btn btn-down"><i class="fa fa-caret-down" aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <div class="buttons">
                            <a href="#" class="btn add-to-cart-btn">add to cart</a>
                            <p class="pull-row">
                                <a href="#" class="btn wishlist-btn">wishlist</a>
                            </p>
                        </div>
                    </div>
                </div>    
            </div>
        </div>
    </div>
<?php require("footer.php")?>