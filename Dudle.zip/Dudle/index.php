<?php require('top.php')?>
 <!-- Page Contain -->
 <div class="page-contain">

<!-- Main content -->
<div id="main-content" class="main-content">

    <div class="main-slide block-slider">
        <ul class="dudle-carousel nav-none-on-mobile" data-slick='{"arrows": true, "dots": false, "slidesMargin": 0, "slidesToShow": 1, "infinite": true, "speed": 800}' >
            <li>
                <div class="slide-contain slider-opt03__layout01 mode-03 black-color slide-bgr-mode03-01">
                    <div class="media"></div>
                    <div class="text-content">
                        <i class="first-line">First Line</i>
                        <h3 class="second-line">Second Line</h3>
                        <p class="third-line">Third Line</p>
                        <p class="buttons">
                            <a href="#" class="btn btn-bold">Button</a>
                            <a href="#" class="btn btn-thin">Button</a>
                        </p>
                    </div>
                </div>
            </li>
            <li>
                <div class="slide-contain slider-opt03__layout01 mode-03 slide-bgr-mode03-02">
                    <div class="media">
                    </div>
                    <div class="text-content">
                        <i class="first-line">First Line</i>
                        <h3 class="second-line">Second Line</h3>
                        <p class="third-line">Third Line</p>
                        <p class="buttons">
                            <a href="#" class="btn btn-bold">Button</a>
                            <a href="#" class="btn btn-thin">Button</a>
                        </p>
                    </div>
                </div>
            </li>
            <li>
                <div class="slide-contain slider-opt03__layout01 mode-03 slide-bgr-mode03-03">
                    <div class="media">
                    </div>
                    <div class="text-content">
                        <i class="first-line">First Line</i>
                        <h3 class="second-line">Second Line</h3>
                        <p class="third-line">Third Line</p>
                        <p class="buttons">
                            <a href="#" class="btn btn-bold">Button</a>
                            <a href="#" class="btn btn-thin">Button</a>
                        </p>
                    </div>
                </div>
            </li>
        </ul>
    </div>

<!--------------------------------------------------------->
            <div class="wrap-category xs-margin-top-80px">
                <div class="container">
                    <div class="dudle-title-box style-02 xs-margin-bottom-33px">
                        <span class="subtitle">Subtitle</span>
                        <h3 class="main-title">Categories</h3>
                        <p class="desc">Description</p>
                    </div>
                    <ul class="dudle-carousel nav-center-bold nav-none-on-mobile" data-slick='{"arrows":true,"dots":false,"infinite":false,"speed":400,"slidesMargin":30,"slidesToShow":4, "responsive":[{"breakpoint":1200, "settings":{ "slidesToShow": 3}},{"breakpoint":992, "settings":{ "slidesToShow": 3}},{"breakpoint":768, "settings":{ "slidesToShow": 2, "slidesMargin":10}}, {"breakpoint":500, "settings":{ "slidesToShow": 1}}]}'>
                        <li>
                            <div class="dudle-cat-box-item">
                                <div class="cat-thumb bg">
                                    <a href="category.php" class="cat-link ">
                                        <img src="#" width="277" height="185" alt="">
                                    </a>
                                </div>
                                <a class="cat-info" href="#">
                                    <h4 class="cat-name">Product Name</h4>
                                    <span class="cat-number">Total items</span>
                                </a>
                            </div>
                        </li>
                        <li>
                            <div class="dudle-cat-box-item">
                                <div class="cat-thumb bg">
                                    <a href="category.php" class="cat-link ">
                                        <img src="#" width="277" height="185" alt="">
                                    </a>
                                </div>
                                <a class="cat-info" href="#">
                                    <h4 class="cat-name">Product Name</h4>
                                    <span class="cat-number">Total Items</span>
                                </a>
                            </div>
                        </li>
                        <li>
                            <div class="dudle-cat-box-item">
                                <div class="cat-thumb bg">
                                    <a href="category.php" class="cat-link">
                                        <img src="#" width="277" height="185" alt="">
                                    </a>
                                </div>
                                <a class="cat-info" href="#">
                                    <h4 class="cat-name">Product Name</h4>
                                    <span class="cat-number">Total Items</span>
                                </a>
                            </div>
                        </li>
                        <li>
                            <div class="dudle-cat-box-item">
                                <div class="cat-thumb bg">
                                    <a href="category.php" class="cat-link">
                                        <img src="#" width="277" height="185" alt="">
                                    </a>
                                </div>
                                <a class="cat-info" href="#">
                                    <h4 class="cat-name">Product Name</h4>
                                    <span class="cat-number">Total Items</span>
                                </a>
                            </div>
                        </li>
                        <li>
                            <div class="dudle-cat-box-item">
                                <div class="cat-thumb bg">
                                    <a href="category.php" class="cat-link">
                                        <img src="" width="277" height="185" alt="">
                                    </a>
                                </div>
                                <a class="cat-info" href="#">
                                    <h4 class="cat-name">Product Name</h4>
                                    <span class="cat-number">Total Items</span>
                                </a>
                            </div>
                        </li>
                        <li>
                            <div class="dudle-cat-box-item">
                                <div class="cat-thumb">
                                    <a href="category.php" class="cat-link bg">
                                        <img src="" width="277" height="185" alt="">
                                    </a>
                                </div>
                                <a class="cat-info" href="#">
                                    <h4 class="cat-name">Product Name</h4>
                                    <span class="cat-number">Total Items</span>
                                </a>
                            </div>
                        </li>
                        <li>
                            <div class="dudle-cat-box-item">
                                <div class="cat-thumb">
                                    <a href="category.php" class="cat-link bg">
                                        <img src="#" width="277" height="185" alt="">
                                    </a>
                                </div>
                                <a class="cat-info" href="#">
                                    <h4 class="cat-name">Product Name</h4>
                                    <span class="cat-number">Total Items</span>
                                </a>
                            </div>
                        </li>
                    </ul>
                   
                </div>
            </div>


    <!-- ------------------------------------------------------------>
    <div class="product-tab z-index-20 sm-margin-top-49px xs-margin-top-80px">
        <div class="container">
            <div class="dudle-title-box dudle-title-box__icon-at-top-style hidden-icon-on-mobile">
                <h3 class="main-title">Title</h3>
                <span class="subtitle">Subtitle</span>
            </div>
            <div class="dudle-tab dudle-tab-contain sm-margin-top-32px">
                <div class="tab-content">
                    <div id="tab02_1st" class="tab-contain active">
                        <ul class="products-list dudle-carousel nav-center-02 nav-none-on-mobile eq-height-contain" data-slick='{"rows":1 ,"arrows":true,"dots":false,"infinite":true,"speed":400,"slidesMargin":10,"slidesToShow":4, "responsive":[{"breakpoint":1200, "settings":{ "slidesToShow": 4}},{"breakpoint":992, "settings":{ "slidesToShow": 3, "slidesMargin":30}},{"breakpoint":768, "settings":{ "slidesToShow": 2, "rows":2, "slidesMargin":15}}]}'>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="single_product.php" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                <a href="#" class="btn compare-btn"><i class="fa fa-random" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="single_product.php" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                <a href="#" class="btn compare-btn"><i class="fa fa-random" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="single_product.php" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                <a href="#" class="btn compare-btn"><i class="fa fa-random" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="single_product.php" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                <a href="#" class="btn compare-btn"><i class="fa fa-random" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="single_product.php" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                <a href="#" class="btn compare-btn"><i class="fa fa-random" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="single_product.php" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                <a href="#" class="btn compare-btn"><i class="fa fa-random" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                       
                          </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="product-tab z-index-20 sm-margin-top-49px xs-margin-top-80px">
        <div class="container">
            <div class="dudle-title-box dudle-title-box__icon-at-top-style hidden-icon-on-mobile">
                <h3 class="main-title">Title</h3>
                <span class="subtitle">Subtitle</span>
            </div>
            <div class="dudle-tab dudle-tab-contain sm-margin-top-32px">
                <div class="tab-content">
                    <div id="tab02_1st" class="tab-contain active">
                        <ul class="products-list dudle-carousel nav-center-02 nav-none-on-mobile eq-height-contain" data-slick='{"rows":1 ,"arrows":true,"dots":false,"infinite":true,"speed":400,"slidesMargin":10,"slidesToShow":4, "responsive":[{"breakpoint":1200, "settings":{ "slidesToShow": 4}},{"breakpoint":992, "settings":{ "slidesToShow": 3, "slidesMargin":30}},{"breakpoint":768, "settings":{ "slidesToShow": 2, "rows":2, "slidesMargin":15}}]}'>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="single_product.php" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                <a href="#" class="btn compare-btn"><i class="fa fa-random" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="single_product.php" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                <a href="#" class="btn compare-btn"><i class="fa fa-random" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                <a href="#" class="btn compare-btn"><i class="fa fa-random" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                <a href="#" class="btn compare-btn"><i class="fa fa-random" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                <a href="#" class="btn compare-btn"><i class="fa fa-random" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                                <a href="#" class="btn compare-btn"><i class="fa fa-random" aria-hidden="true"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                       
                          </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="banner-block md-margin-top-61px sm-margin-bottom-89px xs-margin-top-60px">
        <div class="dudle-banner special-02 dudle-banner__special-02">
            <div class="container">
                <div class="banner-contain">
                    <div class="thumb" style="background-color: #f3f3f3">
                        <a href="#" class="link"><img src="#" width="753" height="517" alt=""></a>
                    </div>
                    <div class="text-content">
                        <i class="text01">Name</i>
                        <b class="text02">Special Offer</b>
                        <div class="product-detail">
                            <h4 class="product-name">Product Name</h4>
                            <div class="price price-contain">
                                <ins><span class="price-amount"><span class="currencySymbol">Symbol</span>Price</span></ins>
                            </div>
                            <div class="buttons">
                                <a href="#" class="btn add-to-cart-btn" tabindex="-1">add to cart</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

      <div class="banner-promotion-01 xs-margin-top-50px sm-margin-top-11px">
                <div class="dudle-banner promotion dudle-banner__promotion">
                    <div class="banner-contain">
                        <div class="media background-dudle-banner__promotion">
                            <div class="img-moving position-1">
                                <img src="#" width="149" height="139" alt="">
                            </div>
                            <div class="img-moving position-2">
                                <img src="#" width="185" height="265" alt="">
                            </div>
                            <div class="img-moving position-3">
                                <img src="#" width="384" height="151" alt="">
                            </div>
                            <div class="img-moving position-4">
                                <img src="#" width="198" height="269" alt="">
                            </div>
                        </div>
                        <div class="text-content">
                            <div class="container text-wrap">
                                <i class="first-line">First Line</i>
                                <span class="second-line">Second Line</span>
                                <p class="third-line">Description (Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aspernatur excepturi in officiis quia et odio dignissimos. Ad, ratione! Aliquid, molestiae?)</p>
                                <div class="product-detail">
                                    <p class="txt-price"><span>..</span>Price</p>
                                    <a href="#" class="btn add-to-cart-btn">add to cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="Product-box sm-margin-top-96px xs-margin-top-0">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-5 col-sm-6">
                            <div class="advance-product-box">
                                <div class="dudle-title-box bold-style dudle-title-box__bold-style">
                                    <h3 class="title">Deals of the day</h3>
                                </div>
                                <ul class="products dudle-carousel nav-top-right nav-none-on-mobile" data-slick='{"arrows":true, "dots":false, "infinite":false, "speed":400, "slidesMargin":30, "slidesToShow":1}'>
                                <li class="product-item">
                                        <div class="contain-product deal-layout contain-product__deal-layout">
                                            <div class="product-thumb">
                                                <a href="#" class="link-to-product">
                                                    <img src="" alt="dd" width="330" height="330" class="product-thumnail">
                                                </a>
                                                <div class="labels">
                                                    <span class="sale-label">Discount (0%)</span>
                                                </div>
                                            </div>
                                            <div class="info">
                                                <div class="dudle-countdown" data-datetime="2021/06/24 12:00:00"></div>
                                                <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                                <div class="price ">
                                                    <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                                    <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                                </div>
                                                <div class="slide-down-box">
                                                    <p class="message">Description</p>
                                                    <div class="buttons">
                                                        <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                        <a href="#" class="btn add-to-cart-btn">add to cart</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                     <li class="product-item">
                                        <div class="contain-product deal-layout contain-product__deal-layout">
                                            <div class="product-thumb">
                                                <a href="#" class="link-to-product">
                                                    <img src="" alt="dd" width="330" height="330" class="product-thumnail">
                                                </a>
                                                <div class="labels">
                                                    <span class="sale-label">Discount (0%)</span>
                                                </div>
                                            </div>
                                            <div class="info">
                                                <div class="dudle-countdown" data-datetime="2021/06/24 12:00:00"></div>
                                                <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                                <div class="price ">
                                                    <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                                    <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                                </div>
                                                <div class="slide-down-box">
                                                    <p class="message">Description</p>
                                                    <div class="buttons">
                                                        <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                        <a href="#" class="btn add-to-cart-btn">add to cart</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="product-item">
                                        <div class="contain-product deal-layout contain-product__deal-layout">
                                            <div class="product-thumb">
                                                <a href="#" class="link-to-product">
                                                    <img src="" alt="dd" width="330" height="330" class="product-thumnail">
                                                </a>
                                                <div class="labels">
                                                    <span class="sale-label">Discount (0%)</span>
                                                </div>
                                            </div>
                                            <div class="info">
                                                <div class="dudle-countdown" data-datetime="2021/06/24 12:00:00"></div>
                                                <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                                <div class="price ">
                                                    <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                                    <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                                </div>
                                                <div class="slide-down-box">
                                                    <p class="message">Description</p>
                                                    <div class="buttons">
                                                        <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                        <a href="#" class="btn add-to-cart-btn">add to cart</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-7 col-sm-6">
                            <div class="advance-product-box">
                                <div class="dudle-title-box bold-style dudle-title-box__bold-style">
                                    <h3 class="title">Title</h3>
                                </div>
                                <ul class="products dudle-carousel eq-height-contain nav-center-03 nav-none-on-mobile row-space-29px" data-slick='{"rows":2,"arrows":true,"dots":false,"infinite":false,"speed":400,"slidesMargin":30,"slidesToShow":2,"responsive":[{"breakpoint":1200,"settings":{ "rows":2, "slidesToShow": 2}},{"breakpoint":992, "settings":{ "rows":2, "slidesToShow": 1}},{"breakpoint":768, "settings":{ "rows":2, "slidesToShow": 2}},{"breakpoint":500, "settings":{ "rows":2, "slidesToShow": 1}}]}'>
                                <li class="product-item">
                                        <div class="contain-product right-info-layout contain-product__right-info-layout">
                                            <div class="product-thumb bg" >
                                                <a href="#" class="link-to-product">
                                                    <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                                </a>
                                            </div>
                                            <div class="info">
                                                <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                                <div class="price ">
                                                    <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                                    <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="product-item">
                                        <div class="contain-product right-info-layout contain-product__right-info-layout">
                                            <div class="product-thumb bg" >
                                                <a href="#" class="link-to-product">
                                                    <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                                </a>
                                            </div>
                                            <div class="info">
                                                <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                                <div class="price ">
                                                    <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                                    <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="product-item">
                                        <div class="contain-product right-info-layout contain-product__right-info-layout">
                                            <div class="product-thumb bg" >
                                                <a href="#" class="link-to-product">
                                                    <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                                </a>
                                            </div>
                                            <div class="info">
                                                <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                                <div class="price ">
                                                    <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                                    <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="product-item">
                                        <div class="contain-product right-info-layout contain-product__right-info-layout">
                                            <div class="product-thumb bg" >
                                                <a href="#" class="link-to-product">
                                                    <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                                </a>
                                            </div>
                                            <div class="info">
                                                <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                                <div class="price ">
                                                    <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                                    <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="product-item">
                                        <div class="contain-product right-info-layout contain-product__right-info-layout">
                                            <div class="product-thumb bg" >
                                                <a href="#" class="link-to-product">
                                                    <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                                </a>
                                            </div>
                                            <div class="info">
                                                <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                                <div class="price ">
                                                    <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                                    <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="product-item">
                                        <div class="contain-product right-info-layout contain-product__right-info-layout">
                                            <div class="product-thumb bg" >
                                                <a href="#" class="link-to-product">
                                                    <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                                </a>
                                            </div>
                                            <div class="info">
                                                <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                                <div class="price ">
                                                    <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                                    <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="product-item">
                                        <div class="contain-product right-info-layout contain-product__right-info-layout">
                                            <div class="product-thumb bg" >
                                                <a href="#" class="link-to-product">
                                                    <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                                </a>
                                            </div>
                                            <div class="info">
                                                <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                                <div class="price ">
                                                    <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                                    <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                                </div>
                                            </div>
                                        </div>
                                    </li>  
                                    <li class="product-item">
                                        <div class="contain-product right-info-layout contain-product__right-info-layout">
                                            <div class="product-thumb bg" >
                                                <a href="#" class="link-to-product">
                                                    <img src="#" alt="dd" width="270" height="270" class="product-thumnail">
                                                </a>
                                            </div>
                                            <div class="info">
                                                <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                                <div class="price ">
                                                    <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                                    <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                                <div class="dudle-banner style-01 dudle-banner__style-01 xs-margin-top-80px-im sm-margin-top-30px-im">
                                    <div class="banner-contain">
                                        <a href="#" class="bn-link"></a>
                                        <div class="text-content">
                                            <span class="first-line">First Line</span>
                                            <b class="second-line">Second Line</b>
                                            <i class="third-line">Third Line</i>
                                            <span class="fourth-line">Fourth Line</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    <div class="product-tab z-index-20 sm-margin-top-71px xs-margin-top-80px">
        <div class="container">
            <div class="dudle-title-box dudle-title-box__icon-at-top-style hidden-icon-on-mobile sm-margin-bottom-24px">
                <h3 class="main-title">Title</h3>
                <span class="subtitle">Subtitle</span>
            </div>
            <div class="dudle-tab dudle-tab-contain">
              <div class="tab-content">
                    <div id="tab01_1st" class="tab-contain active">
                        <ul class="products-list dudle-carousel nav-center-02 nav-none-on-mobile eq-height-contain" data-slick='{"rows":2 ,"arrows":true,"dots":false,"infinite":true,"speed":400,"slidesMargin":10,"slidesToShow":4, "responsive":[{"breakpoint":1200, "settings":{ "slidesToShow": 4}},{"breakpoint":992, "settings":{ "slidesToShow": 3, "slidesMargin": 30}},{"breakpoint":768, "settings":{ "slidesToShow": 2, "slidesMargin": 15}}]}'>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                        <a class="lookup btn_call_quickview" href="#"><i class="dudle-icon icon-search"></i></a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="product-item">
                                <div class="contain-product layout-default">
                                    <div class="product-thumb bg">
                                        <a href="#" class="link-to-product">
                                            <img src="#" alt="" width="270" height="270" class="product-thumnail">
                                        </a>
                                    </div>
                                    <div class="info">
                                        <h4 class="product-title"><a href="#" class="pr-name">Product Name</a></h4>
                                        <div class="price ">
                                            <ins><span class="price-amount"><span class="currencySymbol">.</span>Price</span></ins>
                                            <del><span class="price-amount"><span class="currencySymbol">.</span>Price</span></del>
                                        </div>
                                        <div class="slide-down-box">
                                            <p class="message">Description</p>
                                            <div class="buttons">
                                                <a href="#" class="btn wishlist-btn"><i class="fa fa-heart" aria-hidden="true"></i></a>
                                                <a href="#" class="btn add-to-cart-btn"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i>add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>    
</div>
</div>

<?php require("footer.php")?>